var ReactDOM = require('react-dom');
var routes = require('./routes/routes.jsx');

ReactDOM.render(
	routes, document
);
