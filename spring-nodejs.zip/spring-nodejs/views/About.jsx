var React = require('react');
var createReactClass = require('create-react-class');

module.exports = createReactClass({
	displayName: 'About',
	render: function() {
		return(
			<p>
				Current: <strong>About</strong>
			</p>
		);
	}
});