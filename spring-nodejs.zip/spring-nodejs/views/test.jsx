var React = require('react');
var createReactClass = require('create-react-class');
var ReactDOM = require('react-dom');
var axios = require('axios');
var serialize = require('form-serialize');

module.exports = createReactClass({
	displayName: 'customer_login',
	render: function() {
		return(
            <h1>你好</h1>
		);
	}
});